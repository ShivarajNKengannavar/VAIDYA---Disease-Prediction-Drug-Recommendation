import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const MEDICAL_SYSTEM_PROMPT = `You are VAIDYA, an advanced AI medical diagnostic assistant. You analyze patient symptoms and provide evidence-based preliminary assessments.

CRITICAL GUIDELINES:
1. Always provide 3-5 possible conditions ranked by likelihood
2. Include confidence scores (0-100%) based on symptom correlation
3. Classify severity as: low, medium, or high
4. Provide drug recommendations ONLY for over-the-counter medications
5. Include contraindication checks based on patient allergies and conditions
6. Always include a disclaimer about seeking professional medical advice
7. Consider age and gender in your analysis
8. Be conservative with high confidence scores - only use >80% when symptoms are highly specific

RESPONSE FORMAT (JSON):
{
  "diagnoses": [
    {
      "disease": "Condition Name",
      "confidence": 75,
      "severity": "low|medium|high",
      "description": "Brief medical description",
      "keySymptoms": ["matching symptoms"],
      "recommendations": ["actionable advice"],
      "urgency": "routine|soon|urgent|emergency",
      "specialistType": "type of doctor to consult if needed"
    }
  ],
  "drugs": [
    {
      "name": "Drug Name",
      "dosage": "specific dosage",
      "frequency": "how often",
      "duration": "how long",
      "purpose": "what it treats",
      "warnings": ["important warnings"],
      "contraindicated": false,
      "reason": "why contraindicated if true"
    }
  ],
  "explanation": {
    "reasoning": "Brief explanation of diagnostic reasoning",
    "keyFactors": ["most important factors in analysis"],
    "limitations": "What information would improve accuracy"
  },
  "safetyAlert": null | "Emergency message if symptoms suggest serious condition"
}`;

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { symptoms, age, gender, allergies, chronicConditions } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    console.log("Analyzing symptoms:", { symptoms, age, gender, allergies, chronicConditions });

    const userPrompt = `Analyze the following patient data and provide a comprehensive diagnostic assessment:

PATIENT INFORMATION:
- Age: ${age} years
- Gender: ${gender}
- Reported Symptoms: ${symptoms.join(", ")}
- Known Allergies: ${allergies.length > 0 ? allergies.join(", ") : "None reported"}
- Chronic Conditions: ${chronicConditions.length > 0 ? chronicConditions.join(", ") : "None reported"}

Provide your analysis in the exact JSON format specified. Be thorough but conservative with confidence scores.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: MEDICAL_SYSTEM_PROMPT },
          { role: "user", content: userPrompt }
        ],
        temperature: 0.3,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Service temporarily unavailable. Please try again later." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;
    
    if (!content) {
      throw new Error("No response from AI");
    }

    console.log("AI response received:", content.substring(0, 200));

    // Parse JSON from response (handle markdown code blocks)
    let parsedResult;
    try {
      const jsonMatch = content.match(/```(?:json)?\s*([\s\S]*?)```/);
      const jsonStr = jsonMatch ? jsonMatch[1] : content;
      parsedResult = JSON.parse(jsonStr.trim());
    } catch (parseError) {
      console.error("Failed to parse AI response:", parseError);
      // Return a fallback response
      parsedResult = {
        diagnoses: [{
          disease: "Analysis In Progress",
          confidence: 50,
          severity: "low",
          description: "Based on your symptoms, we recommend consulting with a healthcare provider for a thorough evaluation.",
          keySymptoms: symptoms,
          recommendations: ["Schedule an appointment with your primary care physician", "Keep a symptom diary", "Monitor for any changes"],
          urgency: "routine",
          specialistType: "General Practitioner"
        }],
        drugs: [],
        explanation: {
          reasoning: "The symptom combination requires professional evaluation for accurate diagnosis.",
          keyFactors: symptoms,
          limitations: "A physical examination and potentially lab tests would provide more accurate results."
        },
        safetyAlert: null
      };
    }

    return new Response(JSON.stringify(parsedResult), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Diagnose function error:", error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : "Unknown error occurred" 
    }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
