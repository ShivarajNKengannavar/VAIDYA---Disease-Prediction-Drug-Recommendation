import { motion } from "framer-motion";
import { 
  Brain, 
  Pill, 
  MessageCircle, 
  BarChart3, 
  Shield, 
  Sparkles,
  ArrowRight
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface FeaturesSectionProps {
  onNavigate: (page: string) => void;
}

const features = [
  {
    icon: <Brain className="w-6 h-6" />,
    title: "Explainable AI Diagnosis",
    description: "Understand every prediction with transparent reasoning. See which symptoms matter most and why.",
    color: "text-primary",
    bg: "bg-primary/10",
  },
  {
    icon: <Pill className="w-6 h-6" />,
    title: "Safe Drug Recommendations",
    description: "Get medication suggestions with contraindication checks based on your allergies and conditions.",
    color: "text-accent",
    bg: "bg-accent/10",
  },
  {
    icon: <MessageCircle className="w-6 h-6" />,
    title: "VAIDYA Assistant",
    description: "Chat with our AI health companion to understand your symptoms and get answers to health questions.",
    color: "text-primary",
    bg: "bg-primary/10",
  },
  {
    icon: <BarChart3 className="w-6 h-6" />,
    title: "Health Insights Dashboard",
    description: "Track your health over time with visual analytics, trends, and personalized insights.",
    color: "text-accent",
    bg: "bg-accent/10",
  },
  {
    icon: <Shield className="w-6 h-6" />,
    title: "Privacy by Design",
    description: "Your health data is encrypted, never shared, and you control its deletion anytime.",
    color: "text-success",
    bg: "bg-success/10",
  },
  {
    icon: <Sparkles className="w-6 h-6" />,
    title: "Clinical Safety Layer",
    description: "Low-confidence predictions are flagged. We recommend professional care when uncertain.",
    color: "text-warning",
    bg: "bg-warning/10",
  },
];

const FeaturesSection = ({ onNavigate }: FeaturesSectionProps) => {
  return (
    <section className="py-24 px-4 bg-gradient-to-b from-background to-muted/30">
      <div className="container mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 border border-accent/20 mb-6">
            <Sparkles className="w-4 h-4 text-accent" />
            <span className="text-sm font-medium text-accent">Comprehensive Healthcare AI</span>
          </div>
          <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">
            Everything You Need for{" "}
            <span className="text-gradient">Health Intelligence</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            VAIDYA combines cutting-edge AI with medical safety standards to provide 
            transparent, explainable, and privacy-respecting health insights.
          </p>
        </motion.div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="medical-card group hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
            >
              <div className={`w-12 h-12 rounded-xl ${feature.bg} ${feature.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                {feature.icon}
              </div>
              <h3 className="font-display text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.description}</p>
            </motion.div>
          ))}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="text-center mt-16"
        >
          <Button variant="hero" size="xl" onClick={() => onNavigate("diagnosis")}>
            Try VAIDYA Now
            <ArrowRight className="w-5 h-5" />
          </Button>
        </motion.div>
      </div>
    </section>
  );
};

export default FeaturesSection;
