import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  AlertTriangle, 
  CheckCircle2, 
  Info, 
  ChevronDown, 
  ChevronUp,
  Brain,
  Lightbulb,
  ExternalLink,
  Pill,
  AlertCircle,
  ArrowLeft,
  MessageCircle,
  Loader2,
  FileText,
  Shield,
  Clock,
  Activity,
  Stethoscope,
  RefreshCw,
  Download,
  Share2,
  TrendingUp
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { SymptomData } from "./SymptomInput";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface DiagnosisResultsProps {
  data: SymptomData;
  onBack: () => void;
  onChat: () => void;
}

interface Diagnosis {
  disease: string;
  confidence: number;
  severity: "low" | "medium" | "high";
  description: string;
  keySymptoms: string[];
  recommendations: string[];
  urgency?: string;
  specialistType?: string;
}

interface Drug {
  name: string;
  dosage: string;
  frequency: string;
  duration: string;
  purpose?: string;
  warnings: string[];
  contraindicated: boolean;
  reason?: string;
}

interface AIExplanation {
  reasoning: string;
  keyFactors: string[];
  limitations: string;
}

interface AIResponse {
  diagnoses: Diagnosis[];
  drugs: Drug[];
  explanation: AIExplanation;
  safetyAlert: string | null;
}

const DiagnosisResults = ({ data, onBack, onChat }: DiagnosisResultsProps) => {
  const [expandedDiagnosis, setExpandedDiagnosis] = useState<number | null>(0);
  const [showExplanation, setShowExplanation] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [aiResponse, setAiResponse] = useState<AIResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [analysisTime, setAnalysisTime] = useState(0);

  useEffect(() => {
    const fetchDiagnosis = async () => {
      setIsLoading(true);
      setError(null);
      const startTime = Date.now();

      try {
        const { data: result, error: funcError } = await supabase.functions.invoke('diagnose', {
          body: {
            symptoms: data.symptoms,
            age: data.age,
            gender: data.gender,
            allergies: data.allergies,
            chronicConditions: data.chronicConditions
          }
        });

        if (funcError) {
          throw new Error(funcError.message);
        }

        if (result.error) {
          throw new Error(result.error);
        }

        setAiResponse(result);
        setAnalysisTime(Date.now() - startTime);
      } catch (err) {
        console.error("Diagnosis error:", err);
        setError(err instanceof Error ? err.message : "Failed to analyze symptoms");
        toast.error("Failed to get AI diagnosis. Please try again.");
      } finally {
        setIsLoading(false);
      }
    };

    fetchDiagnosis();
  }, [data]);

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 70) return "text-success";
    if (confidence >= 50) return "text-warning";
    return "text-destructive";
  };

  const getConfidenceLabel = (confidence: number) => {
    if (confidence >= 80) return "High";
    if (confidence >= 60) return "Moderate";
    if (confidence >= 40) return "Low";
    return "Very Low";
  };

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case "high":
        return <Badge variant="destructive">High Priority</Badge>;
      case "medium":
        return <Badge className="bg-warning text-warning-foreground">Medium</Badge>;
      default:
        return <Badge variant="secondary">Low</Badge>;
    }
  };

  const getUrgencyIcon = (urgency?: string) => {
    switch (urgency) {
      case "emergency":
        return <AlertCircle className="w-4 h-4 text-destructive" />;
      case "urgent":
        return <Clock className="w-4 h-4 text-warning" />;
      case "soon":
        return <Activity className="w-4 h-4 text-primary" />;
      default:
        return <Clock className="w-4 h-4 text-muted-foreground" />;
    }
  };

  const handleExportReport = () => {
    if (!aiResponse) return;
    
    const report = `
VAIDYA AI Health Analysis Report
Generated: ${new Date().toLocaleString()}
Analysis Duration: ${analysisTime}ms

PATIENT INFORMATION
==================
Age: ${data.age} years
Gender: ${data.gender}
Symptoms: ${data.symptoms.join(", ")}
Allergies: ${data.allergies.length > 0 ? data.allergies.join(", ") : "None reported"}
Chronic Conditions: ${data.chronicConditions.length > 0 ? data.chronicConditions.join(", ") : "None reported"}

DIAGNOSTIC ASSESSMENT
====================
${aiResponse.diagnoses.map((d, i) => `
${i + 1}. ${d.disease}
   Confidence: ${d.confidence}%
   Severity: ${d.severity}
   Description: ${d.description}
   Matching Symptoms: ${d.keySymptoms.join(", ")}
   Recommendations: ${d.recommendations.join("; ")}
   ${d.specialistType ? `Suggested Specialist: ${d.specialistType}` : ""}
`).join("\n")}

MEDICATION SUGGESTIONS
=====================
${aiResponse.drugs.map(d => `
- ${d.name} ${d.contraindicated ? "(CONTRAINDICATED)" : ""}
  ${d.contraindicated ? `Reason: ${d.reason}` : `Dosage: ${d.dosage}, ${d.frequency}, ${d.duration}`}
  ${d.purpose ? `Purpose: ${d.purpose}` : ""}
  Warnings: ${d.warnings.join("; ")}
`).join("\n")}

AI ANALYSIS EXPLANATION
======================
Reasoning: ${aiResponse.explanation.reasoning}
Key Factors: ${aiResponse.explanation.keyFactors.join(", ")}
Limitations: ${aiResponse.explanation.limitations}

DISCLAIMER
==========
This analysis is for informational purposes only and does not constitute medical advice.
Always consult a qualified healthcare provider for diagnosis and treatment.
    `;

    const blob = new Blob([report], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `vaidya-report-${new Date().toISOString().split("T")[0]}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Report downloaded successfully");
  };

  if (isLoading) {
    return (
      <section className="min-h-screen py-12 px-4 flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center space-y-6"
        >
          <div className="relative">
            <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
              <Brain className="w-12 h-12 text-primary animate-pulse" />
            </div>
            <motion.div
              className="absolute inset-0 rounded-full border-4 border-primary/30 border-t-primary"
              animate={{ rotate: 360 }}
              transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
            />
          </div>
          <div>
            <h2 className="font-display text-2xl font-bold mb-2">Analyzing Your Symptoms</h2>
            <p className="text-muted-foreground">Our AI is processing your health data...</p>
          </div>
          <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="w-4 h-4 animate-spin" />
            <span>Running diagnostic algorithms</span>
          </div>
        </motion.div>
      </section>
    );
  }

  if (error || !aiResponse) {
    return (
      <section className="min-h-screen py-12 px-4 flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-6 max-w-md"
        >
          <div className="w-20 h-20 rounded-full bg-destructive/10 flex items-center justify-center mx-auto">
            <AlertCircle className="w-10 h-10 text-destructive" />
          </div>
          <div>
            <h2 className="font-display text-2xl font-bold mb-2">Analysis Failed</h2>
            <p className="text-muted-foreground">{error || "Unable to complete the analysis. Please try again."}</p>
          </div>
          <div className="flex gap-3 justify-center">
            <Button variant="outline" onClick={onBack}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Go Back
            </Button>
            <Button onClick={() => window.location.reload()}>
              <RefreshCw className="w-4 h-4 mr-2" />
              Retry
            </Button>
          </div>
        </motion.div>
      </section>
    );
  }

  const { diagnoses, drugs, explanation, safetyAlert } = aiResponse;

  return (
    <section className="min-h-screen py-12 px-4">
      <div className="container max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between mb-6 flex-wrap gap-4"
        >
          <Button variant="ghost" onClick={onBack}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            New Analysis
          </Button>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={handleExportReport}>
              <Download className="w-4 h-4 mr-2" />
              Export Report
            </Button>
            <Button variant="hero" onClick={onChat}>
              <MessageCircle className="w-4 h-4 mr-2" />
              Chat with VAIDYA
            </Button>
          </div>
        </motion.div>

        {/* Safety Alert */}
        {safetyAlert && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass rounded-xl p-4 mb-6 border-destructive/50 bg-destructive/10"
          >
            <div className="flex items-start gap-3">
              <AlertCircle className="w-6 h-6 text-destructive flex-shrink-0" />
              <div>
                <p className="font-semibold text-destructive">Urgent Medical Alert</p>
                <p className="text-sm">{safetyAlert}</p>
              </div>
            </div>
          </motion.div>
        )}

        {/* Analysis Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8"
        >
          <div className="stat-card">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <Stethoscope className="w-4 h-4" />
              <span className="text-xs">Symptoms Analyzed</span>
            </div>
            <p className="text-2xl font-bold">{data.symptoms.length}</p>
          </div>
          <div className="stat-card">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <TrendingUp className="w-4 h-4" />
              <span className="text-xs">Conditions Found</span>
            </div>
            <p className="text-2xl font-bold">{diagnoses.length}</p>
          </div>
          <div className="stat-card">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <Shield className="w-4 h-4" />
              <span className="text-xs">Safety Checks</span>
            </div>
            <p className="text-2xl font-bold text-success">Passed</p>
          </div>
          <div className="stat-card">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <Clock className="w-4 h-4" />
              <span className="text-xs">Analysis Time</span>
            </div>
            <p className="text-2xl font-bold">{(analysisTime / 1000).toFixed(1)}s</p>
          </div>
        </motion.div>

        {/* Disclaimer */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="glass rounded-xl p-4 mb-8 border-warning/30 bg-warning/5"
        >
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-warning flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-medium text-sm">Medical Disclaimer</p>
              <p className="text-sm text-muted-foreground">
                This AI-powered analysis is for informational purposes only and does not constitute medical advice. 
                Confidence scores reflect symptom pattern matching, not diagnostic certainty. Always consult a qualified healthcare provider.
              </p>
            </div>
          </div>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Diagnoses */}
          <div className="lg:col-span-2 space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-display text-2xl font-bold">Possible Conditions</h2>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => setShowExplanation(!showExplanation)}
                >
                  <Lightbulb className="w-4 h-4 mr-2" />
                  {showExplanation ? "Hide" : "AI Explanation"}
                </Button>
              </div>

              <AnimatePresence>
                {showExplanation && explanation && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="medical-card mb-4 bg-primary/5 border-primary/20"
                  >
                    <div className="flex items-start gap-3">
                      <Brain className="w-5 h-5 text-primary flex-shrink-0" />
                      <div className="space-y-3">
                        <div>
                          <p className="font-medium text-sm mb-1">Diagnostic Reasoning</p>
                          <p className="text-sm text-muted-foreground">{explanation.reasoning}</p>
                        </div>
                        <div>
                          <p className="font-medium text-sm mb-1">Key Factors Considered</p>
                          <div className="flex flex-wrap gap-2">
                            {explanation.keyFactors.map((factor, i) => (
                              <Badge key={i} variant="outline" className="bg-primary/5">
                                {factor}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <div>
                          <p className="font-medium text-sm mb-1">Limitations</p>
                          <p className="text-sm text-muted-foreground">{explanation.limitations}</p>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {diagnoses.map((diagnosis, index) => (
                <motion.div
                  key={diagnosis.disease}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 + index * 0.1 }}
                  className="medical-card"
                >
                  <div 
                    className="flex items-start justify-between cursor-pointer"
                    onClick={() => setExpandedDiagnosis(expandedDiagnosis === index ? null : index)}
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2 flex-wrap">
                        <h3 className="font-display text-lg font-semibold">{diagnosis.disease}</h3>
                        {getSeverityBadge(diagnosis.severity)}
                        {diagnosis.urgency && (
                          <Badge variant="outline" className="flex items-center gap-1">
                            {getUrgencyIcon(diagnosis.urgency)}
                            {diagnosis.urgency}
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="flex-1 max-w-xs">
                          <div className="flex items-center justify-between text-sm mb-1">
                            <span className="text-muted-foreground">Confidence</span>
                            <span className={`font-medium ${getConfidenceColor(diagnosis.confidence)}`}>
                              {diagnosis.confidence}% ({getConfidenceLabel(diagnosis.confidence)})
                            </span>
                          </div>
                          <Progress value={diagnosis.confidence} className="h-2" />
                        </div>
                      </div>
                    </div>
                    <Button variant="ghost" size="icon">
                      {expandedDiagnosis === index ? <ChevronUp /> : <ChevronDown />}
                    </Button>
                  </div>

                  <AnimatePresence>
                    {expandedDiagnosis === index && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        className="mt-4 pt-4 border-t space-y-4"
                      >
                        <p className="text-muted-foreground">{diagnosis.description}</p>
                        
                        <div>
                          <p className="text-sm font-medium mb-2">Matching Symptoms:</p>
                          <div className="flex flex-wrap gap-2">
                            {diagnosis.keySymptoms.map(s => (
                              <Badge key={s} variant="outline" className="bg-primary/5">
                                <CheckCircle2 className="w-3 h-3 mr-1 text-success" />
                                {s}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        <div>
                          <p className="text-sm font-medium mb-2">Recommendations:</p>
                          <ul className="space-y-1">
                            {diagnosis.recommendations.map((rec, i) => (
                              <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                                <Info className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                                {rec}
                              </li>
                            ))}
                          </ul>
                        </div>

                        {diagnosis.specialistType && (
                          <div className="flex items-center gap-2 p-3 bg-muted/50 rounded-lg">
                            <Stethoscope className="w-4 h-4 text-primary" />
                            <span className="text-sm">
                              Suggested specialist: <strong>{diagnosis.specialistType}</strong>
                            </span>
                          </div>
                        )}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              ))}
            </motion.div>
          </div>

          {/* Drug Recommendations Sidebar */}
          <div className="space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
            >
              <h2 className="font-display text-2xl font-bold mb-4 flex items-center gap-2">
                <Pill className="w-6 h-6 text-primary" />
                Medication Suggestions
              </h2>

              {drugs.length === 0 ? (
                <div className="stat-card text-center py-8">
                  <Shield className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">
                    No over-the-counter medications recommended. Please consult a healthcare provider.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {drugs.map((drug) => (
                    <div 
                      key={drug.name}
                      className={`stat-card ${drug.contraindicated ? 'border-destructive/50 bg-destructive/5' : ''}`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <h4 className="font-semibold">{drug.name}</h4>
                        {drug.contraindicated && (
                          <Badge variant="destructive" className="text-xs">
                            <AlertCircle className="w-3 h-3 mr-1" />
                            Avoid
                          </Badge>
                        )}
                      </div>
                      
                      {drug.contraindicated ? (
                        <p className="text-sm text-destructive">{drug.reason}</p>
                      ) : (
                        <>
                          {drug.purpose && (
                            <p className="text-xs text-muted-foreground mb-2">{drug.purpose}</p>
                          )}
                          <div className="grid grid-cols-2 gap-2 text-sm mb-3">
                            <div>
                              <span className="text-muted-foreground">Dosage:</span>
                              <p className="font-medium">{drug.dosage}</p>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Frequency:</span>
                              <p className="font-medium">{drug.frequency}</p>
                            </div>
                            <div className="col-span-2">
                              <span className="text-muted-foreground">Duration:</span>
                              <p className="font-medium">{drug.duration}</p>
                            </div>
                          </div>
                          <div className="space-y-1">
                            {drug.warnings.map((w, i) => (
                              <p key={i} className="text-xs text-warning flex items-start gap-1">
                                <AlertTriangle className="w-3 h-3 flex-shrink-0 mt-0.5" />
                                {w}
                              </p>
                            ))}
                          </div>
                        </>
                      )}
                    </div>
                  ))}
                </div>
              )}

              <p className="text-xs text-muted-foreground mt-4 p-3 bg-muted/50 rounded-lg">
                <Shield className="w-3 h-3 inline mr-1" />
                These are over-the-counter suggestions only. Prescription medications require 
                consultation with a licensed healthcare provider.
              </p>
            </motion.div>

            {/* Patient Summary */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="stat-card"
            >
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <FileText className="w-4 h-4 text-primary" />
                Analysis Summary
              </h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Patient Age:</span>
                  <span>{data.age} years</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Gender:</span>
                  <span>{data.gender}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Symptoms:</span>
                  <span>{data.symptoms.length} reported</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Allergies:</span>
                  <span>{data.allergies.length || "None"}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Conditions:</span>
                  <span>{data.chronicConditions.length || "None"}</span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DiagnosisResults;
