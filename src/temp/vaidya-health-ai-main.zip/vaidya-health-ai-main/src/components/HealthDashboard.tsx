import { motion } from "framer-motion";
import { 
  Activity, 
  TrendingUp, 
  Calendar, 
  Heart,
  Brain,
  Shield,
  ArrowLeft,
  BarChart3
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from "recharts";

interface HealthDashboardProps {
  onBack: () => void;
}

// Sample data for charts
const healthTrendData = [
  { date: "Mon", score: 75, symptoms: 2 },
  { date: "Tue", score: 72, symptoms: 3 },
  { date: "Wed", score: 78, symptoms: 1 },
  { date: "Thu", score: 82, symptoms: 1 },
  { date: "Fri", score: 80, symptoms: 2 },
  { date: "Sat", score: 85, symptoms: 0 },
  { date: "Sun", score: 88, symptoms: 0 },
];

const symptomDistribution = [
  { name: "Headache", value: 35, color: "hsl(var(--primary))" },
  { name: "Fatigue", value: 28, color: "hsl(var(--accent))" },
  { name: "Cough", value: 20, color: "hsl(var(--warning))" },
  { name: "Other", value: 17, color: "hsl(var(--muted-foreground))" },
];

const consultationHistory = [
  { date: "2024-01-15", condition: "Upper Respiratory Infection", confidence: 78 },
  { date: "2024-01-10", condition: "Tension Headache", confidence: 85 },
  { date: "2024-01-05", condition: "General Fatigue", confidence: 62 },
];

const HealthDashboard = ({ onBack }: HealthDashboardProps) => {
  return (
    <section className="min-h-screen py-12 px-4 bg-gradient-to-b from-background to-muted/30">
      <div className="container max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between mb-8"
        >
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={onBack}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <div>
              <h1 className="font-display text-3xl font-bold">Health Insights</h1>
              <p className="text-muted-foreground">Your personal health analytics</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-primary" />
            <span className="text-sm text-muted-foreground">Last updated: Today</span>
          </div>
        </motion.div>

        {/* Stats Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8"
        >
          <StatCard
            title="Health Score"
            value="88"
            subtitle="Great condition"
            icon={<Heart className="w-5 h-5" />}
            trend="+5% this week"
            trendUp={true}
          />
          <StatCard
            title="Consultations"
            value="12"
            subtitle="This month"
            icon={<Activity className="w-5 h-5" />}
            trend="3 this week"
            trendUp={true}
          />
          <StatCard
            title="Symptoms Tracked"
            value="24"
            subtitle="Across all sessions"
            icon={<Brain className="w-5 h-5" />}
            trend="Most: Headache"
            trendUp={false}
          />
          <StatCard
            title="Privacy Score"
            value="100%"
            subtitle="Data secured"
            icon={<Shield className="w-5 h-5" />}
            trend="Fully encrypted"
            trendUp={true}
          />
        </motion.div>

        {/* Charts Row */}
        <div className="grid lg:grid-cols-3 gap-6 mb-8">
          {/* Health Trend Chart */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="lg:col-span-2"
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-primary" />
                  Health Trend
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={healthTrendData}>
                      <defs>
                        <linearGradient id="healthGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                          <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                      <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} domain={[60, 100]} />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: "hsl(var(--card))", 
                          border: "1px solid hsl(var(--border))",
                          borderRadius: "8px"
                        }}
                      />
                      <Area
                        type="monotone"
                        dataKey="score"
                        stroke="hsl(var(--primary))"
                        strokeWidth={2}
                        fill="url(#healthGradient)"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Symptom Distribution */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="h-full">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="w-5 h-5 text-primary" />
                  Symptom Distribution
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[200px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={symptomDistribution}
                        cx="50%"
                        cy="50%"
                        innerRadius={50}
                        outerRadius={80}
                        paddingAngle={3}
                        dataKey="value"
                      >
                        {symptomDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="space-y-2 mt-4">
                  {symptomDistribution.map((item) => (
                    <div key={item.name} className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                        <span>{item.name}</span>
                      </div>
                      <span className="font-medium">{item.value}%</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Consultation History */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-primary" />
                Recent Consultations
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {consultationHistory.map((consultation, index) => (
                  <div 
                    key={index}
                    className="flex items-center justify-between p-4 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                        <Brain className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium">{consultation.condition}</p>
                        <p className="text-sm text-muted-foreground">{consultation.date}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-muted-foreground mb-1">Confidence</p>
                      <div className="flex items-center gap-2">
                        <Progress value={consultation.confidence} className="w-20 h-2" />
                        <span className="text-sm font-medium">{consultation.confidence}%</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
};

interface StatCardProps {
  title: string;
  value: string;
  subtitle: string;
  icon: React.ReactNode;
  trend: string;
  trendUp: boolean;
}

const StatCard = ({ title, value, subtitle, icon, trend, trendUp }: StatCardProps) => (
  <Card className="overflow-hidden">
    <CardContent className="p-6">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-muted-foreground mb-1">{title}</p>
          <p className="text-3xl font-display font-bold">{value}</p>
          <p className="text-sm text-muted-foreground">{subtitle}</p>
        </div>
        <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
          {icon}
        </div>
      </div>
      <div className={`mt-4 text-xs font-medium ${trendUp ? "text-success" : "text-muted-foreground"}`}>
        {trend}
      </div>
    </CardContent>
  </Card>
);

export default HealthDashboard;
