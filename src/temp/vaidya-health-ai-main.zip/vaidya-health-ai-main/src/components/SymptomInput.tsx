import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Search, 
  ChevronRight, 
  AlertCircle, 
  User, 
  Calendar,
  Pill,
  Stethoscope,
  X,
  Plus
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";

interface SymptomInputProps {
  onSubmit: (data: SymptomData) => void;
  onBack: () => void;
}

export interface SymptomData {
  symptoms: string[];
  age: number;
  gender: string;
  allergies: string[];
  chronicConditions: string[];
}

const COMMON_SYMPTOMS = [
  "Headache", "Fever", "Cough", "Fatigue", "Nausea",
  "Dizziness", "Chest Pain", "Shortness of Breath", "Joint Pain",
  "Sore Throat", "Runny Nose", "Body Aches", "Loss of Appetite"
];

const SymptomInput = ({ onSubmit, onBack }: SymptomInputProps) => {
  const [step, setStep] = useState(1);
  const [symptoms, setSymptoms] = useState<string[]>([]);
  const [customSymptom, setCustomSymptom] = useState("");
  const [age, setAge] = useState<number>(30);
  const [gender, setGender] = useState<string>("");
  const [allergies, setAllergies] = useState<string[]>([]);
  const [allergyInput, setAllergyInput] = useState("");
  const [chronicConditions, setChronicConditions] = useState<string[]>([]);
  const [conditionInput, setConditionInput] = useState("");

  const addSymptom = (symptom: string) => {
    if (symptom && !symptoms.includes(symptom)) {
      setSymptoms([...symptoms, symptom]);
    }
    setCustomSymptom("");
  };

  const removeSymptom = (symptom: string) => {
    setSymptoms(symptoms.filter(s => s !== symptom));
  };

  const addAllergy = () => {
    if (allergyInput && !allergies.includes(allergyInput)) {
      setAllergies([...allergies, allergyInput]);
      setAllergyInput("");
    }
  };

  const addCondition = () => {
    if (conditionInput && !chronicConditions.includes(conditionInput)) {
      setChronicConditions([...chronicConditions, conditionInput]);
      setConditionInput("");
    }
  };

  const handleSubmit = () => {
    onSubmit({ symptoms, age, gender, allergies, chronicConditions });
  };

  const canProceedStep1 = symptoms.length >= 1;
  const canProceedStep2 = age > 0 && gender !== "";
  const canSubmit = canProceedStep1 && canProceedStep2;

  return (
    <section className="min-h-screen py-20 px-4">
      <div className="container max-w-3xl mx-auto">
        {/* Progress indicator */}
        <div className="flex items-center justify-center gap-2 mb-12">
          {[1, 2, 3].map((s) => (
            <div
              key={s}
              className={`h-2 rounded-full transition-all duration-300 ${
                s === step ? "w-12 bg-primary" : s < step ? "w-8 bg-primary/50" : "w-8 bg-muted"
              }`}
            />
          ))}
        </div>

        <AnimatePresence mode="wait">
          {/* Step 1: Symptoms */}
          {step === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              transition={{ duration: 0.3 }}
              className="space-y-8"
            >
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary/10 text-primary mb-4">
                  <Stethoscope className="w-8 h-8" />
                </div>
                <h2 className="font-display text-3xl font-bold mb-2">Describe Your Symptoms</h2>
                <p className="text-muted-foreground">Select or type the symptoms you're experiencing</p>
              </div>

              {/* Selected symptoms */}
              {symptoms.length > 0 && (
                <div className="flex flex-wrap gap-2 justify-center">
                  {symptoms.map((symptom) => (
                    <Badge
                      key={symptom}
                      variant="secondary"
                      className="px-3 py-2 text-sm bg-primary/10 text-primary border-primary/20 cursor-pointer hover:bg-primary/20"
                      onClick={() => removeSymptom(symptom)}
                    >
                      {symptom}
                      <X className="w-3 h-3 ml-2" />
                    </Badge>
                  ))}
                </div>
              )}

              {/* Custom symptom input */}
              <div className="flex gap-2 max-w-md mx-auto">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    placeholder="Type a symptom..."
                    value={customSymptom}
                    onChange={(e) => setCustomSymptom(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && addSymptom(customSymptom)}
                    className="pl-10 h-12"
                  />
                </div>
                <Button onClick={() => addSymptom(customSymptom)} disabled={!customSymptom}>
                  <Plus className="w-5 h-5" />
                </Button>
              </div>

              {/* Common symptoms */}
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground text-center">Common symptoms:</p>
                <div className="flex flex-wrap gap-2 justify-center">
                  {COMMON_SYMPTOMS.filter(s => !symptoms.includes(s)).map((symptom) => (
                    <Badge
                      key={symptom}
                      variant="outline"
                      className="px-3 py-2 cursor-pointer hover:bg-primary/10 hover:border-primary/40 transition-colors"
                      onClick={() => addSymptom(symptom)}
                    >
                      {symptom}
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="flex justify-between pt-8">
                <Button variant="ghost" onClick={onBack}>
                  Back to Home
                </Button>
                <Button onClick={() => setStep(2)} disabled={!canProceedStep1}>
                  Continue
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </motion.div>
          )}

          {/* Step 2: Personal Info */}
          {step === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              transition={{ duration: 0.3 }}
              className="space-y-8"
            >
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary/10 text-primary mb-4">
                  <User className="w-8 h-8" />
                </div>
                <h2 className="font-display text-3xl font-bold mb-2">About You</h2>
                <p className="text-muted-foreground">This helps us provide more accurate analysis</p>
              </div>

              <div className="max-w-md mx-auto space-y-6">
                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    Age
                  </Label>
                  <Input
                    type="number"
                    value={age}
                    onChange={(e) => setAge(parseInt(e.target.value) || 0)}
                    min={1}
                    max={120}
                    className="h-12"
                  />
                </div>

                <div className="space-y-2">
                  <Label>Gender</Label>
                  <div className="grid grid-cols-3 gap-3">
                    {["Male", "Female", "Other"].map((g) => (
                      <Button
                        key={g}
                        variant={gender === g ? "default" : "outline"}
                        onClick={() => setGender(g)}
                        className="h-12"
                      >
                        {g}
                      </Button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex justify-between pt-8">
                <Button variant="ghost" onClick={() => setStep(1)}>
                  Back
                </Button>
                <Button onClick={() => setStep(3)} disabled={!canProceedStep2}>
                  Continue
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </motion.div>
          )}

          {/* Step 3: Medical History */}
          {step === 3 && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              transition={{ duration: 0.3 }}
              className="space-y-8"
            >
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary/10 text-primary mb-4">
                  <Pill className="w-8 h-8" />
                </div>
                <h2 className="font-display text-3xl font-bold mb-2">Medical History</h2>
                <p className="text-muted-foreground">Optional but helps avoid unsafe recommendations</p>
              </div>

              <div className="max-w-md mx-auto space-y-6">
                {/* Allergies */}
                <div className="space-y-3">
                  <Label className="flex items-center gap-2">
                    <AlertCircle className="w-4 h-4" />
                    Known Allergies
                  </Label>
                  <div className="flex gap-2">
                    <Input
                      placeholder="e.g., Penicillin"
                      value={allergyInput}
                      onChange={(e) => setAllergyInput(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && addAllergy()}
                      className="h-10"
                    />
                    <Button variant="outline" onClick={addAllergy} disabled={!allergyInput}>
                      Add
                    </Button>
                  </div>
                  {allergies.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {allergies.map((a) => (
                        <Badge key={a} variant="destructive" className="cursor-pointer" onClick={() => setAllergies(allergies.filter(x => x !== a))}>
                          {a} <X className="w-3 h-3 ml-1" />
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>

                {/* Chronic Conditions */}
                <div className="space-y-3">
                  <Label>Chronic Conditions</Label>
                  <div className="flex gap-2">
                    <Input
                      placeholder="e.g., Diabetes, Hypertension"
                      value={conditionInput}
                      onChange={(e) => setConditionInput(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && addCondition()}
                      className="h-10"
                    />
                    <Button variant="outline" onClick={addCondition} disabled={!conditionInput}>
                      Add
                    </Button>
                  </div>
                  {chronicConditions.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {chronicConditions.map((c) => (
                        <Badge key={c} variant="secondary" className="cursor-pointer" onClick={() => setChronicConditions(chronicConditions.filter(x => x !== c))}>
                          {c} <X className="w-3 h-3 ml-1" />
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <div className="flex justify-between pt-8">
                <Button variant="ghost" onClick={() => setStep(2)}>
                  Back
                </Button>
                <Button variant="hero" onClick={handleSubmit} disabled={!canSubmit}>
                  Analyze Symptoms
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
};

export default SymptomInput;
