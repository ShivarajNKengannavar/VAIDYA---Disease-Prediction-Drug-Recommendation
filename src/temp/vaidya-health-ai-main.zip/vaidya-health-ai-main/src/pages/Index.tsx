import { useState } from "react";
import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import FeaturesSection from "@/components/FeaturesSection";
import SymptomInput, { SymptomData } from "@/components/SymptomInput";
import DiagnosisResults from "@/components/DiagnosisResults";
import HealthDashboard from "@/components/HealthDashboard";
import ChatBot from "@/components/ChatBot";
import Footer from "@/components/Footer";

type Page = "home" | "diagnosis" | "results" | "dashboard" | "chat";

const Index = () => {
  const [currentPage, setCurrentPage] = useState<Page>("home");
  const [symptomData, setSymptomData] = useState<SymptomData | null>(null);
  const [chatOpen, setChatOpen] = useState(false);

  const handleNavigate = (page: string) => {
    if (page === "chat") {
      setChatOpen(true);
    } else {
      setCurrentPage(page as Page);
    }
  };

  const handleSymptomSubmit = (data: SymptomData) => {
    setSymptomData(data);
    setCurrentPage("results");
  };

  const handleStartDiagnosis = () => {
    setCurrentPage("diagnosis");
  };

  const renderPage = () => {
    switch (currentPage) {
      case "diagnosis":
        return (
          <SymptomInput
            onSubmit={handleSymptomSubmit}
            onBack={() => setCurrentPage("home")}
          />
        );
      case "results":
        return symptomData ? (
          <DiagnosisResults
            data={symptomData}
            onBack={() => {
              setSymptomData(null);
              setCurrentPage("diagnosis");
            }}
            onChat={() => setChatOpen(true)}
          />
        ) : null;
      case "dashboard":
        return <HealthDashboard onBack={() => setCurrentPage("home")} />;
      default:
        return (
          <>
            <HeroSection onStartDiagnosis={handleStartDiagnosis} />
            <FeaturesSection onNavigate={handleNavigate} />
          </>
        );
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header onNavigate={handleNavigate} currentPage={currentPage} />
      <main className="flex-1 pt-16">
        {renderPage()}
      </main>
      {currentPage === "home" && <Footer />}
      <ChatBot
        isOpen={chatOpen}
        onClose={() => setChatOpen(false)}
        initialContext={symptomData ? `You analyzed ${symptomData.symptoms.length} symptoms.` : undefined}
      />
    </div>
  );
};

export default Index;
